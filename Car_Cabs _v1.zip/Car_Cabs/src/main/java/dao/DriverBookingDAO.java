package dao;
import Bean.BookingRequest;
import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Bean.BookingRequest;

public class DriverBookingDAO {

    /**
     * Accepts a booking request by moving it from RequestBooking to Bookings table.
     * Updates the status of the request to 'Accepted' and assigns the driver.
     *
     * @param requestId The ID of the request to accept
     * @param driverUsername The username of the driver accepting the request
     * @return An empty string if successful, or an error message if an error occurs
     */
	public static String acceptBooking(int requestId, String driverUsername) {
	    Connection conn = null;
	    try {
	        conn = DBConnection.getConnection();
	        if (conn == null) {
	            System.out.println("Database connection failed.");
	            return "Database connection failed.";
	        }

	        conn.setAutoCommit(false);

	        // Get booking request details
	        String selectSql = "SELECT * FROM RequestBooking WHERE request_id = ?";
	        PreparedStatement selectStmt = conn.prepareStatement(selectSql);
	        selectStmt.setInt(1, requestId);
	        ResultSet rs = selectStmt.executeQuery();

	        if (rs.next()) {
	            String username = rs.getString("username");
	            String pickup = rs.getString("pickup_location");
	            String dropoff = rs.getString("drop_location");
	            String date = rs.getString("booking_date");
	            String time = rs.getString("time");
	            int passengerCount = rs.getInt("passenger_count");
	            String vehicleType = rs.getString("vehicle_type");
	            double totalAmount = rs.getDouble("total_amount");

	            // Insert into Bookings table
	            String insertSql = "INSERT INTO Bookings (username, driver_id, pickup_location, drop_location, booking_date, time, passenger_count, vehicle_type, total_amount, status) "
	                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Confirmed')";
	            PreparedStatement insertStmt = conn.prepareStatement(insertSql);
	            insertStmt.setString(1, username);
	            insertStmt.setString(2, driverUsername);
	            insertStmt.setString(3, pickup);
	            insertStmt.setString(4, dropoff);
	            insertStmt.setString(5, date);
	            insertStmt.setString(6, time);
	            insertStmt.setInt(7, passengerCount);
	            insertStmt.setString(8, vehicleType);
	            insertStmt.setDouble(9, totalAmount);

	            int rowsInserted = insertStmt.executeUpdate();
	            if (rowsInserted > 0) {
	                System.out.println("Booking accepted. Inserting into Bookings table.");

	                // Update request status to Accepted
	                String updateSql = "UPDATE RequestBooking SET status = 'Accepted' WHERE request_id = ?";
	                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
	                updateStmt.setInt(1, requestId);
	                updateStmt.executeUpdate();

	                conn.commit();
	                return ""; // Success
	            }
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	        return "Error: " + e.getMessage();
	    } finally {
	        if (conn != null) {
	            try {
	                conn.setAutoCommit(true);
	                conn.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	    return "Failed to accept booking.";
	}


    /**
     * Retrieves all pending ride requests regardless of vehicle type.
     * @return A list of pending ride requests
     */
    

    /**
     * Retrieves all pending ride requests matching the driver's vehicle type.
     * @param vehicleType The type of vehicle the driver is authorized to drive
     * @return A list of pending ride requests
     */
   

    public static List<BookingRequest> getPendingRequests() {
        Connection conn = null;
        List<BookingRequest> pendingRequests = new ArrayList<>();
        try {
            conn = DBConnection.getConnection();
            if (conn == null) {
                System.out.println("Database connection failed.");
                return pendingRequests;
            }

            String sql = "SELECT * FROM RequestBooking WHERE status = 'Pending'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                BookingRequest request = new BookingRequest();
                request.setRequestId(rs.getInt("request_id"));
                request.setUsername(rs.getString("username"));
                request.setPickupLocation(rs.getString("pickup_location"));
                request.setDropoffLocation(rs.getString("drop_location"));
                request.setBookingDate(rs.getString("booking_date"));
                request.setTime(rs.getString("time"));
                request.setPassengerCount(rs.getInt("passenger_count"));
                request.setVehicleType(rs.getString("vehicle_type"));
                request.setTotalAmount(rs.getDouble("total_amount"));
                request.setStatus(rs.getString("status"));

                pendingRequests.add(request);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return pendingRequests;
    }





    /**
     * Rejects a booking request by updating its status to 'Cancelled' in the RequestBooking table.
     *
     * @param requestId The ID of the request to reject
     * @return An empty string if successful, or an error message if an error occurs
     */
    public static String rejectBooking(int requestId) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            if (conn == null) {
                return "Database connection failed.";
            }

            String sql = "UPDATE RequestBooking SET status = 'Cancelled' WHERE request_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, requestId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                return ""; // Success
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return "Failed to reject booking.";
    }
}
