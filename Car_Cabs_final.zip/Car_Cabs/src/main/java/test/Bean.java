package test;

public class Bean {

}
